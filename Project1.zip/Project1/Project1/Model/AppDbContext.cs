﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Project1.Model;

namespace Project1.Model
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }

        public DbSet<Customer> customers { get; set; }
        public DbSet<Rental> rentals { get; set; }
        public DbSet<Order> orders { get; set; }
        public DbSet<DiscountDetail> discountDetails { get; set; }
        public DbSet<Car> cars { get; set; }
        public DbSet<CarCategorie> carCategories { get; set; }
        public DbSet<Address> addresses { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //seed  Customer
            modelBuilder.Entity<Order>().HasData(new Order
            {
                
                OrderId = 1,
                EmailId = "kr21101999@gmail.com",
                Password = "kr21101999@gmail.com",
                Name = "roshan",
                Gender = "Male",
                Occupation="Emp",
                Address="xhg czdfgbvd  bvkudfjvb duc h",
                DOB="21.01.1999",
                PhoneNo=9873275357,
                AadharNo=8888666633332222


            });
            modelBuilder.Entity<Order>().HasData(new Order
            {

                OrderId = 2,
                EmailId = "sk21101999@gmail.com",
                Password = "sk21101999@gmail.com",
                Name = "saurabh",
                Gender = "Male",
                Occupation = "Emp",
                Address = "xhg czdfgbvd  bvkudfjvb duc h",
                DOB = "26.01.1997",
                PhoneNo = 9873275357,
                AadharNo = 3338666633332222


            });
            modelBuilder.Entity<Order>().HasData(new Order
            {

                OrderId = 3,
                EmailId = "sd21101999@gmail.com",
                Password = "sd21101999@gmail.com",
                Name = "shubham",
                Gender = "Male",
                Occupation = "Emp",
                Address = "xhg czdfgbvd  bvkudfjvb duc h",
                DOB = "06.01.1995",
                PhoneNo = 9873275357,
                AadharNo = 8228666633332222


            });

            //seed DiscountDetail
            modelBuilder.Entity<DiscountDetail>().HasData(new DiscountDetail
            {
                DiscountId=1,
                CustomerType="yearly membersship",
                 Discount="50"
            });
            modelBuilder.Entity<DiscountDetail>().HasData(new DiscountDetail
            {
                DiscountId = 2,
                CustomerType = "Monthly members",
                 Discount="25"
            });
            modelBuilder.Entity<DiscountDetail>().HasData(new DiscountDetail
            {
                DiscountId = 3,
                CustomerType = "half yearly members",
                Discount = "25"
            });

            //seed Car
            modelBuilder.Entity<Car>().HasData(new Car
            {
                VehicleId =1,
                Description = " the boxes categorically used for the engine, passenger, and cargo.",
                model = "Ciaz",
                ImgUrl= "https://i.ndtvimg.com/i/2015-11/maruti-suzuki-ciaz-827_827x510_61447071611.jpg",
                CostPerMile=20,
              CatgoriesId = 2
            });
            modelBuilder.Entity<Car>().HasData(new Car
            {
                VehicleId = 2,
                Description = "A hatchback is a car type with a rear door that opens upwards. They typically feature a four-door configuration, excluding the rear door ",
                model = "Swift",
                ImgUrl = "https://i.ndtvimg.com/i/2016-04/maruti-suzuki-swift_827x510_71460371276.jpg",
                CostPerMile = 15,
                CatgoriesId = 2
            });
            modelBuilder.Entity<Car>().HasData(new Car
            {
                VehicleId = 3,
                Description = " They feature either a retractable hardtop roof or soft folding top. ",
              model = "A3",
                ImgUrl = "https://i.ndtvimg.com/i/2014-12/audi-a3-cabriolet-3_625x300_51417497918.jpg",
                CostPerMile = 17,
                 CatgoriesId = 1

            });

            //seed CarCategorie
            modelBuilder.Entity<CarCategorie>().HasData(new CarCategorie
            {
                CatgoriesId = 1,
                Brand= "Audi"

            });
            modelBuilder.Entity<CarCategorie>().HasData(new CarCategorie
            {
                CatgoriesId = 2,
                Brand = "Maruti Suzuki "

            });

           
        }

        public DbSet<Project1.Model.Address> Address { get; set; }
       
    }
}
